#!/usr/bin/perl
# ===================================================================
# @(#)CBGP.pm
#
# @author Bruno Quoitin (bqu@info.ucl.ac.be)
# @date 19/02/2004
# @lastdate 18/08/2004
# ===================================================================
# This package is an helper for Perl scripts that want to use C-BGP in
# an interactive way. The package uses a pair of pipes created thanks
# to the IPC::Open2 module. Those pipes are used to write to and read
# from a C-BGP instance.
#
# Note that particular attention must be paid to the way the input and
# output are read and written. Since we are in presence of two
# separate processes that are cooperating, deadlocks can occur. Simple
# precautions will avoid most of the problems due to pipe buffering:
#
# 1). use the "set autoflush on" statement in the C-BGP script will
# activate an automatic flush of the C-BGP output after the following
# commands: show rib, show rib-in, show networks, show peers and
# record-route. More C-BGP commands will hopefully support this
# feature in the future.
#
# 2). use the autoflush() method on the output descriptor returned by
# open2() in the Perl script. This is done by the class in this
# package.
#
# 3). provide a non-buffered read of the C-BGP output through calls to
# sysread instead of read of the <> operator. This is also done by the
# class in this package.
# ===================================================================

package CBGP;

require Exporter;
@ISA= qw(Exporter);
@EXPORT= qw(new spawn expect send finalize);
$VERSION= '0.3';

use strict;
use warnings;

use IO::Handle;
use IO::Select;
use IPC::Open2;
use POSIX;
use Symbol;
use threads;
use Thread::Queue;
use Thread::Semaphore;

return 1;

# -----[ thread status ]-----
use constant THREAD_NOT_RUNNING => 0;
use constant THREAD_RUNNING => 1;
use constant THREAD_TERMINATED => 2;
use constant THREAD_ABORTED => -1;

# -----[ logging options ]-----
use constant LOG_FILE => ".CBGP.pm.log";
use constant LOG_DEFAULT => 0;

# -----[ new ]-------------------------------------------------------
# Create a new instance of a C-BGP wrapper
# -------------------------------------------------------------------
sub new(@)
{
    my $class= shift;
    my $cbgp_prog= "cbgp";

    if ($] == 5.008) {
	print STDERR "Warning (CBGP.pm): version 5.8.0 of Perl suffers from memory leaks\n";
    }

    # Any spec for the cbgp program
    if (scalar(@_) > 0) {
	$cbgp_prog= shift;
    }
    # Any spec for the log ?
    if (scalar(@_) > 0) {
	$cbgp_prog= $cbgp_prog." -l ".shift;
    } else {
	$cbgp_prog= $cbgp_prog." -l /dev/null";
    }
    # Redirect C-BGP stderr to stdout
    $cbgp_prog= $cbgp_prog." 2>&1";

    # Shared variable with input lines
    my $thread_status : shared = THREAD_NOT_RUNNING;

    my $cbgp_ref = {
	'queue' => new Thread::Queue,
	'in_file' => gensym(),             # create anonymous globs for file
				           # descriptors (one for input
	'out_file' => gensym(),            # and one for output)
	'pid' => -1,                       # PID of spawned C-BGP process
	'prog' => $cbgp_prog,              # C-BGP command-line
	'thread' => undef,                 # Reader thread
	'thread_status' => \$thread_status,
	'ready' => new Thread::Semaphore(0),
	'log' => LOG_DEFAULT,
    };
    bless $cbgp_ref;

    unlink ".CBGP.pm.log";

    return $cbgp_ref;
}


# -----[ thread_reader ]---------------------------------------------
# This thread
# -------------------------------------------------------------------
sub thread_reader($)
{
    my $self= shift;
    my $tin= 1;
    my $input_buffer= "";
    my $thread_terminate= 0;

    close $self->{out_file} or
	 die "Error: unable to close output pipe";

    # Signal that the reader thread is now running
    ${$self->{thread_status}}= THREAD_RUNNING;
    $self->{ready}->up(1);

    # Loop while the input descriptor is open...
    while ($thread_terminate != 1) {

        # Create handle set for reading and add input file descriptor
        my $read_set = new IO::Select();
        $read_set->add($self->{in_file});

	my $rh_set = IO::Select->select($read_set, undef, undef, $tin);
	if ($rh_set > 0) {

	    # We use sysread in order to bypass the buffering
	    # mechanism of Perl. New data are put at the end of the
	    # current input buffer
	    my $n= sysread($self->{in_file}, $input_buffer,
			   1024, length($input_buffer));

            my @new_lines;

	    if ($n == 0) {

		#print STDERR "Debug (CBGP thread): input closed\n";

		# End of file met, returns everything remaining in
		# input buffer
		if ($input_buffer) {
		    push @new_lines, ($input_buffer);
		}
		$input_buffer= "";
		$thread_terminate= 1;

	    } elsif ($n > 0) {

		# Split the buffer. If the last line does not terminate
		# with an end-of-line, accumulate it in the input buffer
		if ($input_buffer=~ m/\n$/) {
		    @new_lines= split /\n/, $input_buffer;
		    $input_buffer= "";
		} else {
		    @new_lines= split /\n/, $input_buffer;
		    $input_buffer= pop @new_lines;
		}

	    } else {

		# An error has occured
		print STDERR "Error (CBGP thread): sysread: $!\n";
		print STDERR "Debug (CBGP thread): aborted\n";
		${$self->{thread_running}}= THREAD_ABORTED;
		return -1;

	    }

	    $self->{queue}->enqueue(@new_lines);
		
	} elsif ($rh_set < 0) {

	    # An error has occured
	    print STDERR "Error (CBGP thread): select: $!\n";
	    print STDERR "Debug (CBGP thread): aborted\n";
	    ${$self->{thread_status}}= THREAD_ABORTED;
	    return -1;

	}
    }

    close $self->{in_file} or
	 die "Error: unable to close input pipe";

    #print STDERR "Debug (CBGP thread): terminated\n";
    ${$self->{thread_status}}= THREAD_TERMINATED;

    return 0;
}


# -----[ spawn ]-----------------------------------------------------
# Spawn a C-BGP instance and a thread that reads the output of C-BGP
# -------------------------------------------------------------------
sub spawn()
{
    my $self= shift;

    # Spawn C-BGP process and returns two file descriptors. One for
    # the input pipe used to send messages to the C-BGP instance and
    # another for the output pipe to receive answers from the C-BGP
    # instance
    $self->{pid} = open2($self->{in_file}, $self->{out_file},
			 $self->{prog});

    # Activate autoflush on the output descriptor
    $self->{out_file}->autoflush();

    # Spawn a new thread in order to read the C-BGP input as soon as
    # it is available. Then wait until the thread has really started
    # otherwize, input could be missed.
    $self->{thread}= threads->new(\&thread_reader, $self);
    $self->{ready}->down(1);

    # Close the input descriptor on the caller (parent) side. Keep
    # them open in the thread
    close $self->{in_file} or
	  die "Error: unable to close input pipe";

}


# -----[ expect ]----------------------------------------------------
# Expect input from the C-BGP instance. The call can be either
# blocking or non-blocking.
#
# Parameters:
# - blocking: 1 => the call will block if there is nothing to read
#             0 => the call will never block
# -------------------------------------------------------------------
sub expect($)
{
    my $self= shift;
    my $blocking= shift;

    (($blocking == 0) || ($blocking == 1)) or
	die "expect's <blocking> parameter must be 0 or 1";

    if ($blocking) {
	return $self->{queue}->dequeue;
    } else {
	return $self->{queue}->dequeue_nb;
    }

    return undef;
}


# -----[ send ]------------------------------------------------------
# Send a command to the C-BGP instance
# -------------------------------------------------------------------
sub send($)
{
    my $self= shift;
    my $msg= shift;

    my $out_file= $self->{out_file};

    if (!$out_file->opened || $out_file->error ||
	(${$self->{thread_status}} != THREAD_RUNNING)) {
	#print STDERR "Error: output to CBGP has been closed\n";
	return -1;
    }

    if ($self->{log}) {
	if (open(CBGP_LOG, ">>".LOG_FILE)) {
	    print CBGP_LOG "$msg";
	    close(CBGP_LOG);
	}
    }
    $out_file->print("$msg");

    return 0;
}


# -----[ finalize ]--------------------------------------------------
# Close pipes and wait for termination of the C-BGP instance and the
# reader thread
# -------------------------------------------------------------------
sub finalize()
{
    my $self= shift;

    #print STDERR "Debug: finalize\n";

    close $self->{out_file} or
	  die "Error: unable to close output pipe";

    # Wait for the thread termination
    if ($self->{thread}) {
	my $res= $self->{thread}->join();
	if ($res != 0) {
	    print STDERR "Error: CBGP thread exited abnormaly\n";
	}
    }

    # Wait until the C-BGP instance has terminated. This avoids an
    # accumulation of defunct processes
    waitpid($self->{pid}, 0);

}


__END__

=head1 NAME

CBGP - Perl wrapper for C-BGP

=head1 VERSION

0.1

=head1 SYNOPSIS

use CBGP;

$cbgp= new CBGP;

$cbgp->spawn();

$cbgp->send();

$cbgp->expect();

$cbgp->finalize();

=head1 DESCRIPTION

This package is an helper for Perl scripts that want to use C-BGP in
an interactive way. The package uses a pair of pipes created thanks
to the IPC::Open2 module. Those pipes are used to write to and read
from a C-BGP instance.

Note that particular attention must be paid to the way the input and
output are read and written. Since we are in presence of two
separate processes that are cooperating, deadlocks can occur. Simple
precautions will avoid most of the problems due to pipe buffering:

1). use the "set autoflush on" statement in the C-BGP script will
activate an automatic flush of the C-BGP output after the following
commands: show rib, show rib-in, show networks, show peers and
record-route. More C-BGP commands will hopefully support this
feature in the future.

2). use the autoflush() method on the output descriptor returned by
open2() in the Perl script. This is done by the class in this
package. This is also done by the class in this package.

3). provide a non-buffered read of the C-BGP output through calls to
sysread instead of read of the <> operator.

=head1 AUTHORS

Bruno Quoitin (bqu@info.ucl.ac.be), from the CSE Department of
University of Louvain-la-Neuve, in Belgium.

=head1 COPYRIGHT

This Perl package is provided under the LGPL license. Please have a
look at the Free Software Foundation (http://www.fsf.org) if you are
not familiar with this kind of license.

=head1 DISCLAIMER

This software is provided ``as is'' and any express or implied
warranties, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose are disclaimed.
in no event shall the authors be liable for any direct, indirect,
incidental, special, exemplary, or consequential damages (including,
but not limited to, procurement of substitute goods or services; loss
of use, data, or profits; or business interruption) however caused and
on any theory of liability, whether in contract, strict liability, or
tort (including negligence or otherwise) arising in any way out of the
use of this software, even if advised of the possibility of such
damage.

=cut
