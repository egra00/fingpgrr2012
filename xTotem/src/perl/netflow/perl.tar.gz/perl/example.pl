#!/usr/bin/perl
# ===================================================================
# @(#)perl-example.pl
#
# @author Bruno Quoitin (bqu@info.ucl.ac.be)
# @date 03/06/2004
# @lastdate 18/08/2004
# ===================================================================

use strict;
use lib ".";

use CBGP 0.3;

# -----[ perl_core ]-------------------------------------------------
# Simple example that feeds C-BGP with a 2 router configuration then
# dumps the BGP routing tables
# -------------------------------------------------------------------
sub perl_core($)
{
    my $cbgp= shift;

    # Feed configuration
    $cbgp->send("set autoflush on\n");
    $cbgp->send("net add node 0.0.1.1\n");
    $cbgp->send("net add node 0.0.1.2\n");
    $cbgp->send("net add link 0.0.1.1 0.0.1.2 15\n");
    $cbgp->send("net node 0.0.1.1 spf-prefix 0.0.1/24\n");
    $cbgp->send("net node 0.0.1.2 spf-prefix 0.0.1/24\n");
    $cbgp->send("bgp add router 1 0.0.1.1\n");
    $cbgp->send("bgp router 0.0.1.1\n");
    $cbgp->send("  add network 0.0.1/24\n");
    $cbgp->send("  add peer 1 0.0.1.2\n");
    $cbgp->send("  peer 0.0.1.2 up\n");
    $cbgp->send("  exit\n");
    $cbgp->send("bgp add router 1 0.0.1.2\n");
    $cbgp->send("bgp router 0.0.1.2\n");
    $cbgp->send("  add network 0.0.2/24\n");
    $cbgp->send("  add peer 1 0.0.1.1\n");
    $cbgp->send("  peer 0.0.1.1 up\n");
    $cbgp->send("  exit\n");
    $cbgp->send("sim run\n");
    $cbgp->send("print \"CONFIGURATION OK\\n\"\n");
    
    # Expect "CONFIGURATION OK"
    $_= $cbgp->expect(1);
    chomp;
    if ($_ ne "CONFIGURATION OK") {
	 die "Beeeeeh !!!";
    }

    # Request a routing table dump from router 0.0.1.1
    $cbgp->send("print \"# This is the RIB of router 0.0.1.1:\\n\"\n");
    $cbgp->send("bgp router 0.0.1.1 show rib *\n");
    $cbgp->send("print \"done\\n\"\n");

    while ($_= $cbgp->expect(1)) {
	 chomp;
	 m/^done/ and last;
	 print "(1) read:[$_]\n";
    }

    # Request a routing table dump from router 0.0.1.2
    $cbgp->send("print \"# This is the RIB of router 0.0.1.2:\\n\"\n");
    $cbgp->send("bgp router 0.0.1.2 show rib *\n");
    $cbgp->send("print \"done\\n\"\n");

    while ($_= $cbgp->expect(1)) {
	 chomp;
	 m/^done/ and last;
	 print "(2) read:[$_]\n";
    }

}


# -----[ main ]------------------------------------------------------
# -------------------------------------------------------------------
my $cbgp= CBGP->new("../tests/cbgp-1.1.15/src/cbgp");

$cbgp->spawn;

perl_core($cbgp);

$cbgp->finalize;

while (my $res= $cbgp->expect(0)) {
    print STDERR "Debug: expect \"$res\"\n";
}

